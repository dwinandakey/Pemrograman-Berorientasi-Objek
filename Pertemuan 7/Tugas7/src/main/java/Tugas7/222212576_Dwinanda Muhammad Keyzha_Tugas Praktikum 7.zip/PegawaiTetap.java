/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas7;

/**
 *
 * @author Dwinanda
 */
public class PegawaiTetap extends Pegawai {

  public PegawaiTetap(String nama) {
    setNama(nama);
    setTipe("Permanen");
    setPembayarangaji("Perbulan");
  }
}
