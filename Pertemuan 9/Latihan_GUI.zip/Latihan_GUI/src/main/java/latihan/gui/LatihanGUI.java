/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package latihan.gui;

/**
 *
 * @author Dwinanda
 */
public class LatihanGUI {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
