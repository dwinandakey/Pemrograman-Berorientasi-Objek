/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PraPertemuan4.No4;

/**
 *
 * @author Dwinanda
 */
public interface Resizable {

    public void resize(int percent);
}
