/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PraPertemuan5;

/**
 *
 * @author Dwinanda
 */
public class Dean extends Employee {

  Dean(int ssNo, String name, String email) {
    super(ssNo, name, email);
  }

  @Override
  public String toString() {
    return super.toString();
  }
}
